# CFG ↔ PDA Visualizer

An interactive web application that demonstrates the conversion between **Context-Free Grammars (CFG)** and **Pushdown Automata (PDA)**, built as an educational tool for Theory of Computation courses.

---

## 🚀 Live Demo

Open `index.html` in any modern browser — **no build step, no dependencies, no server required.**

---

## ✨ Features

| Feature | Description |
|---|---|
| **CFG → PDA Conversion** | Converts any CFG into an equivalent 3-state PDA using the Sipser construction |
| **Formal PDA Definition** | Displays Q, Σ, Γ, δ, q₀, F with a complete transition table |
| **CFG Grammar Diagram** | Canvas-rendered visual of all production rules |
| **PDA State Diagram** | Canvas-rendered state diagram showing q_start → q_loop → q_accept |
| **Step-by-Step Explanation** | 4-step conversion walkthrough with formal notation |
| **String Testing** | Tests any input string for acceptance with leftmost derivation trace |
| **4 Built-in Presets** | aⁿbⁿ, Palindromes, Arithmetic Expressions, Equal a's and b's |
| **Theory Reference** | In-app theory tab with CFG/PDA definitions and the equivalence theorem |

---

## 📐 Conversion Algorithm

The tool implements the standard **Sipser CFG → PDA construction** (Theorem 2.20):

Given CFG G = (V, Σ, R, S), construct PDA P = (Q, Σ, Γ, δ, q_start, {q_accept}):

1. **States**: Q = {q_start, q_loop, q_accept}
2. **Init**: δ(q_start, ε, ε) = {(q_loop, S$)}
3. **Variable rules**: For each A → w ∈ R: δ(q_loop, ε, A) ∋ (q_loop, w)
4. **Terminal matching**: For each a ∈ Σ: δ(q_loop, a, a) = {(q_loop, ε)}
5. **Accept**: δ(q_loop, ε, $) = {(q_accept, ε)}

---

## 🗂 Project Structure

```
cfg-pda-visualizer/
├── index.html          # Main application shell
├── css/
│   └── style.css       # Full styling (dark terminal theme)
└── js/
    ├── parser.js       # CFG text parser (tokenizer + grammar builder)
    ├── converter.js    # CFG→PDA algorithm + string tester (BFS derivation)
    ├── visualizer.js   # HTML5 Canvas diagram renderer
    └── app.js          # UI controller / event handlers
```

---

## 🧪 Supported CFG Syntax

```
S → aSb | ε
E → E+T | T
T → T*F | F
F → (E) | a
```

- Arrows: `→`, `->`, `::=`, `=>`
- Epsilon: `ε`, `eps`, `epsilon`
- Alternatives separated by `|`
- Variables: uppercase letters (optionally followed by lowercase/digits)
- Terminals: lowercase letters, digits, or symbols

---

## 📚 How to Use

1. **Enter** a CFG in the text area (or select a preset)
2. **Click** "Convert to PDA"
3. **Explore** the output tabs:
   - *CFG Parse Tree* — visual grammar diagram
   - *PDA Diagram* — state machine diagram
   - *Conversion Steps* — step-by-step explanation
4. **Test strings** in the String Testing tab

---

## 🔬 Example Grammars

| Name | Grammar | Language |
|---|---|---|
| Balanced | `S → aSb \| ε` | {aⁿbⁿ \| n ≥ 0} |
| Palindrome | `S → aSa \| bSb \| a \| b \| ε` | Palindromes over {a,b} |
| Arithmetic | `E → E+T \| T` / `T → T*F \| F` / `F → (E) \| a` | Arithmetic expressions |
| Equal counts | `S → aSbS \| bSaS \| ε` | Equal a's and b's |

---

## 🛠 Technologies

- **Vanilla HTML5 / CSS3 / JavaScript** — zero dependencies
- **HTML5 Canvas API** — for state and grammar diagrams
- **Google Fonts** — JetBrains Mono + Syne

---

## 📖 References

- Sipser, M. (2012). *Introduction to the Theory of Computation* (3rd ed.) — Theorem 2.20
- Hopcroft, Motwani & Ullman — *Introduction to Automata Theory, Languages and Computation*
