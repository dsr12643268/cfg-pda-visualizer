// ============================================================
//  CFG PARSER — Parses raw text into a grammar object
// ============================================================

const CFGParser = (() => {

  /**
   * Parse raw textarea text into a CFG object.
   * Supports:
   *   S → a | b | ε
   *   S -> aSb | ε
   *   S ::= aSb | ε
   * Returns: { variables, terminals, rules, startSymbol }
   * Throws string error messages on bad input.
   */
  function parse(text, startSymbol = 'S') {
    const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length === 0) throw 'No grammar rules provided.';

    const rules = [];   // { lhs: string, rhs: string[] }
    const variables = new Set();
    const terminals = new Set();

    for (const line of lines) {
      // Support →, ->, ::=, =>
      const match = line.match(/^([A-Z][A-Za-z0-9_']*)\s*(?:→|->|::=|=>)\s*(.+)$/);
      if (!match) throw `Cannot parse rule: "${line}"`;

      const lhs = match[1].trim();
      const rhsPart = match[2].trim();
      variables.add(lhs);

      // Split alternatives by |
      const alternatives = rhsPart.split('|').map(a => a.trim());
      for (const alt of alternatives) {
        const symbols = tokenizeRHS(alt);
        rules.push({ lhs, rhs: symbols });
      }
    }

    // Collect terminals: anything in RHS that isn't a variable or ε
    for (const rule of rules) {
      for (const sym of rule.rhs) {
        if (sym !== 'ε' && sym !== 'eps' && !variables.has(sym)) {
          terminals.add(sym);
        }
      }
    }

    // Validate start symbol
    if (!variables.has(startSymbol)) {
      throw `Start symbol "${startSymbol}" not found in grammar variables.`;
    }

    // Normalize ε
    const normalizedRules = rules.map(r => ({
      lhs: r.lhs,
      rhs: r.rhs.map(s => (s === 'eps' ? 'ε' : s)).filter(s => s !== '')
    }));

    return {
      variables: [...variables],
      terminals: [...terminals],
      rules: normalizedRules,
      startSymbol
    };
  }

  /**
   * Tokenize a RHS string into symbols.
   * Variables: uppercase letters optionally followed by lowercase/digits/underscore/'
   * Terminals: lowercase letters, digits, or special chars like +, *, (, )
   * ε/eps = epsilon
   */
  function tokenizeRHS(rhs) {
    if (rhs === 'ε' || rhs === 'eps' || rhs === 'epsilon') return ['ε'];
    if (rhs === '') return ['ε'];

    const symbols = [];
    let i = 0;
    while (i < rhs.length) {
      // Skip spaces
      if (rhs[i] === ' ') { i++; continue; }

      // ε or eps
      if (rhs.startsWith('ε', i)) { symbols.push('ε'); i += 1; continue; }
      if (rhs.startsWith('eps', i)) { symbols.push('ε'); i += 3; continue; }

      // Variable: uppercase + optional lowercase/digits/underscore/'
      if (/[A-Z]/.test(rhs[i])) {
        let sym = rhs[i++];
        while (i < rhs.length && /[A-Za-z0-9_']/.test(rhs[i])) sym += rhs[i++];
        symbols.push(sym);
        continue;
      }

      // Terminal: everything else is a single char
      symbols.push(rhs[i]);
      i++;
    }
    return symbols.length > 0 ? symbols : ['ε'];
  }

  /**
   * Convert grammar back to display string.
   */
  function grammarToString(grammar) {
    const lines = [];
    // Group rules by lhs
    const grouped = {};
    for (const rule of grammar.rules) {
      if (!grouped[rule.lhs]) grouped[rule.lhs] = [];
      const rhs = rule.rhs.length === 0 ? 'ε' : rule.rhs.join('');
      grouped[rule.lhs].push(rhs);
    }
    // Start symbol first
    if (grouped[grammar.startSymbol]) {
      lines.push(`${grammar.startSymbol} → ${grouped[grammar.startSymbol].join(' | ')}`);
    }
    for (const v of grammar.variables) {
      if (v !== grammar.startSymbol && grouped[v]) {
        lines.push(`${v} → ${grouped[v].join(' | ')}`);
      }
    }
    return lines.join('\n');
  }

  return { parse, grammarToString, tokenizeRHS };
})();
