// ============================================================
//  VISUALIZER — Draws CFG grammar diagram and PDA state diagram
//  onto HTML5 Canvas elements
// ============================================================

const Visualizer = (() => {

  // ── Theme colours ──────────────────────────────────────────
  const C = {
    bg:       '#0f1218',
    panel:    '#131820',
    border:   '#1e2a3a',
    border2:  '#2a3a50',
    accent:   '#00e5ff',
    accent2:  '#ff6b35',
    accent3:  '#7cff6b',
    text:     '#d0dce8',
    textDim:  '#5a7080',
    textMid:  '#8aa0b0',
    yellow:   '#ffd166',
  };

  // ─────────────────────────────────────────────────────────────
  //  PDA STATE DIAGRAM
  // ─────────────────────────────────────────────────────────────

  function drawPDA(canvas, pda) {
    if (!pda) return;

    const W = 800, H = 380;
    canvas.width  = W;
    canvas.height = H;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, W, H);

    // Background
    ctx.fillStyle = C.bg;
    ctx.fillRect(0, 0, W, H);

    // State positions
    const states = {
      q_start:  { x: 110, y: H/2, label: 'q_start',  color: C.yellow  },
      q_loop:   { x: 400, y: H/2, label: 'q_loop',   color: C.accent  },
      q_accept: { x: 690, y: H/2, label: 'q_accept', color: C.accent3 }
    };

    const R = 46;

    // ── Draw arrows ──────────────────────────────────────────
    // Group transitions by (from,to)
    const groups = {};
    for (const t of pda.transitions) {
      const key = `${t.from}→${t.to}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(t);
    }

    for (const [key, trans] of Object.entries(groups)) {
      const from = states[trans[0].from];
      const to   = states[trans[0].to];
      if (!from || !to) continue;

      if (from === to) {
        // Self-loop on q_loop
        drawSelfLoop(ctx, from.x, from.y, R, trans, C.accent);
      } else {
        drawArrow(ctx, from, to, R, trans);
      }
    }

    // ── Draw states ──────────────────────────────────────────
    for (const [id, st] of Object.entries(states)) {
      const isAccept = pda.accept.includes(id);
      const isStart  = pda.start === id;

      // Glow
      ctx.shadowColor  = st.color;
      ctx.shadowBlur   = 18;
      ctx.beginPath();
      ctx.arc(st.x, st.y, R, 0, Math.PI*2);
      ctx.strokeStyle = st.color;
      ctx.lineWidth   = 2;
      ctx.fillStyle   = '#0a0e14';
      ctx.fill();
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Double circle for accept
      if (isAccept) {
        ctx.beginPath();
        ctx.arc(st.x, st.y, R - 8, 0, Math.PI*2);
        ctx.strokeStyle = st.color;
        ctx.lineWidth   = 1.5;
        ctx.stroke();
      }

      // Arrow for start
      if (isStart) {
        ctx.beginPath();
        ctx.moveTo(st.x - R - 30, st.y);
        ctx.lineTo(st.x - R - 5, st.y);
        ctx.strokeStyle = C.yellow;
        ctx.lineWidth   = 2;
        ctx.stroke();
        drawArrowHead(ctx, st.x - R - 5, st.y, 0, C.yellow);
      }

      // Label
      ctx.font      = 'bold 13px JetBrains Mono, monospace';
      ctx.fillStyle = st.color;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(st.label, st.x, st.y);
    }

    // Legend
    drawLegend(ctx, W, H);
  }

  function drawArrow(ctx, from, to, R, transitions) {
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const dist = Math.hypot(dx, dy);
    const nx = dx / dist, ny = dy / dist;

    const sx = from.x + nx * R;
    const sy = from.y + ny * R;
    const ex = to.x   - nx * (R + 8);
    const ey = to.y   - ny * (R + 8);

    // Line
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(ex, ey);
    ctx.strokeStyle = C.border2;
    ctx.lineWidth   = 1.5;
    ctx.stroke();
    drawArrowHead(ctx, ex, ey, Math.atan2(ny, nx), C.border2);

    // Label — build compact summary
    const labels = buildTransitionLabels(transitions);
    const mx = (sx + ex) / 2;
    const my = (sy + ey) / 2 - 18;

    ctx.font = '11px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    labels.forEach((lbl, i) => {
      const y = my - (labels.length - 1 - i) * 15 + (labels.length - 1) * 7;
      ctx.fillStyle = transitions[i] ? typeColor(transitions[Math.min(i, transitions.length-1)].type) : C.textMid;
      ctx.fillText(lbl, mx, y);
    });
  }

  function drawSelfLoop(ctx, x, y, R, transitions, color) {
    // Draw loop above q_loop
    const loopR = 44;
    const cy = y - R - loopR + 4;

    ctx.beginPath();
    ctx.arc(x, cy, loopR, 0, Math.PI * 2);
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 3]);
    ctx.stroke();
    ctx.setLineDash([]);

    // Arrow at bottom of loop
    drawArrowHead(ctx, x + loopR * 0.15, cy + loopR - 2, Math.PI * 0.7, color);

    // Count labels by type
    const varCount = transitions.filter(t => t.type === 'var').length;
    const termCount = transitions.filter(t => t.type === 'term').length;

    ctx.font = '10px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const labelY = cy - loopR - 8;
    ctx.fillStyle = C.accent;
    ctx.fillText(`${varCount} variable rule(s)`, x, labelY);
    ctx.fillStyle = C.accent2;
    ctx.fillText(`${termCount} terminal match(es)`, x, labelY + 14);
  }

  function buildTransitionLabels(transitions) {
    // Show first 3, then summarize
    const labels = [];
    const shown = transitions.slice(0, 2);
    for (const t of shown) {
      const inp = t.input === 'ε' ? 'ε' : t.input;
      const pop = t.stackPop === 'ε' ? 'ε' : t.stackPop;
      const psh = (t.displayPush || t.stackPush) === 'ε' ? 'ε' : (t.displayPush || t.stackPush);
      labels.push(`${inp},${pop}→${psh}`);
    }
    if (transitions.length > 2) {
      labels.push(`+${transitions.length - 2} more…`);
    }
    return labels;
  }

  function typeColor(type) {
    switch (type) {
      case 'init':   return C.yellow;
      case 'var':    return C.accent;
      case 'term':   return C.accent2;
      case 'accept': return C.accent3;
      default:       return C.textMid;
    }
  }

  function drawArrowHead(ctx, x, y, angle, color) {
    const size = 8;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-size, -size/2);
    ctx.lineTo(-size, size/2);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
    ctx.restore();
  }

  function drawLegend(ctx, W, H) {
    const items = [
      { color: C.yellow,  label: 'Init'   },
      { color: C.accent,  label: 'Var rule' },
      { color: C.accent2, label: 'Terminal' },
      { color: C.accent3, label: 'Accept'  },
    ];
    let lx = 20;
    const ly = H - 22;
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.textBaseline = 'middle';
    for (const item of items) {
      ctx.fillStyle = item.color;
      ctx.fillRect(lx, ly - 5, 10, 10);
      ctx.fillStyle = C.textMid;
      ctx.textAlign = 'left';
      ctx.fillText(item.label, lx + 14, ly);
      lx += 80;
    }
  }

  // ─────────────────────────────────────────────────────────────
  //  CFG GRAMMAR DIAGRAM (production rules visualisation)
  // ─────────────────────────────────────────────────────────────

  function drawCFG(canvas, grammar) {
    if (!grammar) return;

    const { variables, terminals, rules, startSymbol } = grammar;
    const W = 800;

    // Calculate height dynamically
    const rowH = 52;
    const H = Math.max(300, rules.length * rowH + 100);
    canvas.width  = W;
    canvas.height = H;

    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = C.bg;
    ctx.fillRect(0, 0, W, H);

    // Title
    ctx.font = 'bold 13px Syne, sans-serif';
    ctx.fillStyle = C.textDim;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText('GRAMMAR PRODUCTION RULES', 24, 16);

    // Group rules by variable
    const grouped = {};
    for (const v of variables) grouped[v] = [];
    for (const rule of rules) {
      if (grouped[rule.lhs]) grouped[rule.lhs].push(rule);
    }

    let y = 50;
    const COL_LHS = 60;
    const COL_ARROW = 130;
    const COL_RHS = 165;

    for (const v of variables) {
      const vRules = grouped[v];
      if (!vRules || vRules.length === 0) continue;

      const isStart = v === startSymbol;

      // Variable bubble
      ctx.shadowColor = isStart ? C.yellow : C.accent;
      ctx.shadowBlur  = isStart ? 14 : 8;

      ctx.beginPath();
      roundRect(ctx, COL_LHS - 18, y - 4, 36, 28, 4);
      ctx.fillStyle   = isStart ? 'rgba(255,209,102,0.1)' : 'rgba(0,229,255,0.08)';
      ctx.fill();
      ctx.strokeStyle = isStart ? C.yellow : C.accent;
      ctx.lineWidth   = 1.5;
      ctx.stroke();
      ctx.shadowBlur  = 0;

      ctx.font = 'bold 14px JetBrains Mono, monospace';
      ctx.fillStyle = isStart ? C.yellow : C.accent;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(v, COL_LHS, y + 10);

      // Arrow
      ctx.font = '16px serif';
      ctx.fillStyle = C.textDim;
      ctx.textAlign = 'left';
      ctx.fillText('→', COL_ARROW, y + 2);

      // RHS alternatives
      let rx = COL_RHS;
      for (let i = 0; i < vRules.length; i++) {
        const rule = vRules[i];
        if (i > 0) {
          // Pipe separator
          ctx.font = '14px JetBrains Mono, monospace';
          ctx.fillStyle = C.textDim;
          ctx.fillText(' | ', rx, y + 2);
          rx += measureText(ctx, ' | ', '14px JetBrains Mono, monospace');
        }

        const symbols = rule.rhs.length === 0 ? ['ε'] : rule.rhs;
        for (const sym of symbols) {
          const isVar  = variables.includes(sym);
          const isTerm = terminals.includes(sym);
          const isEps  = sym === 'ε';

          ctx.font = 'bold 13px JetBrains Mono, monospace';
          const tw = measureText(ctx, sym, 'bold 13px JetBrains Mono, monospace');

          // Background pill
          let bg, stroke, fg;
          if (isVar)  { bg = 'rgba(0,229,255,0.07)'; stroke = C.accent;  fg = C.accent; }
          else if (isEps)  { bg = 'rgba(255,209,102,0.07)'; stroke = C.yellow; fg = C.yellow; }
          else        { bg = 'rgba(255,107,53,0.07)'; stroke = C.accent2; fg = C.accent2; }

          ctx.beginPath();
          roundRect(ctx, rx - 2, y, tw + 8, 22, 3);
          ctx.fillStyle = bg;
          ctx.fill();
          ctx.strokeStyle = stroke;
          ctx.lineWidth = 1;
          ctx.stroke();

          ctx.fillStyle = fg;
          ctx.textAlign = 'left';
          ctx.textBaseline = 'top';
          ctx.fillText(sym, rx + 3, y + 4);

          rx += tw + 12;
          if (rx > W - 40) { rx = COL_RHS; y += 32; }
        }
      }

      y += 46;
    }

    // Legend
    const legendItems = [
      { color: C.yellow,  label: 'Start var' },
      { color: C.accent,  label: 'Variable'  },
      { color: C.accent2, label: 'Terminal'  },
      { color: C.yellow,  label: 'ε (epsilon)' },
    ];
    let lx = 24;
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.textBaseline = 'middle';
    for (const item of legendItems) {
      ctx.fillStyle = item.color;
      ctx.fillRect(lx, H - 20, 9, 9);
      ctx.fillStyle = C.textMid;
      ctx.textAlign = 'left';
      ctx.fillText(item.label, lx + 13, H - 15);
      lx += 90;
    }
  }

  // ─────────────────────────────────────────────────────────────
  //  Helpers
  // ─────────────────────────────────────────────────────────────
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  function measureText(ctx, text, font) {
    ctx.font = font;
    return ctx.measureText(text).width;
  }

  return { drawPDA, drawCFG };
})();
