// ============================================================
//  APP.JS — Main controller
// ============================================================

(function () {
  let currentGrammar = null;
  let currentPDA     = null;

  // ── DOM refs ─────────────────────────────────────────────
  const cfgInput     = document.getElementById('cfg-input');
  const startSymbol  = document.getElementById('start-symbol');
  const convertBtn   = document.getElementById('convert-btn');
  const parseError   = document.getElementById('parse-error');
  const pdaOutput    = document.getElementById('pda-output');
  const vizSection   = document.getElementById('viz-section');
  const stepsList    = document.getElementById('steps-list');
  const testString   = document.getElementById('test-string');
  const testBtn      = document.getElementById('test-btn');
  const testResult   = document.getElementById('test-result');
  const derivSteps   = document.getElementById('derivation-steps');

  // ── Tab navigation ───────────────────────────────────────
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });

  // ── Viz tabs ─────────────────────────────────────────────
  document.querySelectorAll('.viz-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.viz-tab').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.viz-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.viz).classList.add('active');
    });
  });

  // ── Presets ──────────────────────────────────────────────
  document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const preset = CFGtoPDA.PRESETS[btn.dataset.preset];
      if (preset) {
        cfgInput.value    = preset.text;
        startSymbol.value = preset.start;
        hideError();
      }
    });
  });

  // ── Convert button ────────────────────────────────────────
  convertBtn.addEventListener('click', () => {
    performConversion();
  });

  // Keyboard shortcut: Ctrl+Enter to convert
  cfgInput.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') performConversion();
  });

  // ── Test button ───────────────────────────────────────────
  testBtn.addEventListener('click', () => {
    performTest();
  });

  testString.addEventListener('keydown', e => {
    if (e.key === 'Enter') performTest();
  });

  // ── Core: convert ─────────────────────────────────────────
  function performConversion() {
    hideError();
    const text  = cfgInput.value.trim();
    const start = startSymbol.value.trim() || 'S';

    if (!text) {
      showError('Please enter at least one grammar rule.');
      return;
    }

    try {
      currentGrammar = CFGParser.parse(text, start);
      currentPDA     = CFGtoPDA.convert(currentGrammar);

      renderPDAOutput(currentGrammar, currentPDA);
      renderConversionSteps(currentPDA.steps);
      renderDiagrams(currentGrammar, currentPDA);
      vizSection.style.display = 'block';

    } catch (err) {
      showError(typeof err === 'string' ? err : err.message);
      vizSection.style.display = 'none';
      pdaOutput.innerHTML = `<div class="placeholder-msg">
        <div class="placeholder-icon">⟳</div>
        <p>Fix errors and try again.</p>
      </div>`;
    }
  }

  // ── Render PDA formal description ─────────────────────────
  function renderPDAOutput(grammar, pda) {
    const { variables, terminals } = grammar;
    const { states, inputAlpha, stackAlpha, start, accept, transitions } = pda;

    // Build transition table HTML
    let transRows = '';
    for (const t of transitions) {
      const inp  = t.input     === 'ε' ? '<em>ε</em>' : esc(t.input);
      const pop  = t.stackPop  === 'ε' ? '<em>ε</em>' : esc(t.stackPop);
      const push = (t.displayPush !== undefined ? t.displayPush : t.stackPush) === 'ε'
        ? '<em>ε</em>'
        : esc(t.displayPush !== undefined ? t.displayPush : t.stackPush);

      transRows += `<tr>
        <td>${esc(t.from)}</td>
        <td>${inp}</td>
        <td>${pop}</td>
        <td>${esc(t.to)}</td>
        <td>${push}</td>
        <td><span class="trans-rule-type ${t.type}">${t.type}</span></td>
        <td style="color:var(--text-dim);font-size:0.72rem">${esc(t.ruleDesc)}</td>
      </tr>`;
    }

    pdaOutput.innerHTML = `
      <div class="pda-def">
        <h3>P = (Q, Σ, Γ, δ, q<sub>start</sub>, F)</h3>

        <div class="pda-section">
          <div class="pda-section-title">Q — States</div>
          <div class="pda-set">
            ${states.map(s => `<span class="pda-symbol state">${esc(s)}</span>`).join('')}
          </div>
        </div>

        <div class="pda-section">
          <div class="pda-section-title">Σ — Input Alphabet</div>
          <div class="pda-set">
            ${inputAlpha.length === 0
              ? '<span class="pda-symbol" style="color:var(--text-dim)">∅ (empty / only ε-rules)</span>'
              : inputAlpha.map(t => `<span class="pda-symbol terminal">${esc(t)}</span>`).join('')}
          </div>
        </div>

        <div class="pda-section">
          <div class="pda-section-title">Γ — Stack Alphabet</div>
          <div class="pda-set">
            ${stackAlpha.map(s => {
              const cls = s === '$' ? 'special' : variables.includes(s) ? 'state' : 'terminal';
              return `<span class="pda-symbol ${cls}">${esc(s)}</span>`;
            }).join('')}
          </div>
        </div>

        <div class="pda-section">
          <div class="pda-section-title">q₀ — Start State</div>
          <div class="pda-set"><span class="pda-symbol state">${esc(start)}</span></div>
        </div>

        <div class="pda-section">
          <div class="pda-section-title">F — Accept States</div>
          <div class="pda-set">
            ${accept.map(s => `<span class="pda-symbol state" style="border-color:var(--accent3);color:var(--accent3)">${esc(s)}</span>`).join('')}
          </div>
        </div>

        <div class="pda-section">
          <div class="pda-section-title">δ — Transition Function (${transitions.length} transitions)</div>
          <div style="overflow-x:auto;margin-top:8px">
          <table class="trans-table">
            <thead>
              <tr>
                <th>From</th>
                <th>Input</th>
                <th>Stack Pop</th>
                <th>To</th>
                <th>Stack Push</th>
                <th>Type</th>
                <th>Description</th>
              </tr>
            </thead>
            <tbody>${transRows}</tbody>
          </table>
          </div>
        </div>
      </div>
    `;
  }

  // ── Render conversion steps ───────────────────────────────
  function renderConversionSteps(steps) {
    stepsList.innerHTML = steps.map(step => `
      <div class="step-item" style="animation-delay:${(step.num - 1) * 0.08}s">
        <div class="step-num">${step.num}</div>
        <div class="step-content">
          <h4>${esc(step.title)}</h4>
          <p>${esc(step.desc)}</p>
          <div class="step-code">${esc(step.code)}</div>
        </div>
      </div>
    `).join('');
  }

  // ── Render canvas diagrams ─────────────────────────────────
  function renderDiagrams(grammar, pda) {
    requestAnimationFrame(() => {
      const cfgCanvas = document.getElementById('cfg-canvas');
      const pdaCanvas = document.getElementById('pda-canvas');
      Visualizer.drawCFG(cfgCanvas, grammar);
      Visualizer.drawPDA(pdaCanvas, pda);
    });
  }

  // ── String testing ─────────────────────────────────────────
  function performTest() {
    if (!currentGrammar) {
      testResult.className = 'test-result no-grammar';
      testResult.innerHTML = '⚠ Please convert a grammar first (CFG → PDA tab).';
      testResult.classList.remove('hidden');
      derivSteps.classList.add('hidden');
      return;
    }

    const input = testString.value;
    if (input === null || input === undefined) return;

    const { accepted, derivation, error } = CFGtoPDA.testString(currentGrammar, input);

    if (error) {
      testResult.className = 'test-result no-grammar';
      testResult.innerHTML = `⚠ ${esc(error)}`;
      testResult.classList.remove('hidden');
      derivSteps.classList.add('hidden');
      return;
    }

    const displayInput = input === '' || input === 'ε' ? 'ε' : `"${input}"`;

    if (accepted) {
      testResult.className = 'test-result accepted';
      testResult.innerHTML = `✓ String ${displayInput} is <strong>ACCEPTED</strong> by the grammar / PDA.`;
    } else {
      testResult.className = 'test-result rejected';
      testResult.innerHTML = `✗ String ${displayInput} is <strong>REJECTED</strong> — not in L(G).`;
    }
    testResult.classList.remove('hidden');

    // Derivation steps
    if (accepted && derivation.length > 0) {
      const rows = derivation.map((d, i) => `
        <div class="deriv-step">
          <span class="deriv-idx">${i}</span>
          <span class="deriv-arrow">${i === 0 ? '⇒' : '⇒'}</span>
          <span class="deriv-expr">${esc(d.expr)}</span>
          ${d.rule !== 'Start' ? `<span class="deriv-rule">[${esc(d.rule)}]</span>` : ''}
        </div>
      `).join('');

      derivSteps.innerHTML = `<h4>Leftmost Derivation</h4>${rows}`;
      derivSteps.classList.remove('hidden');
    } else {
      derivSteps.classList.add('hidden');
    }
  }

  // ── Utilities ─────────────────────────────────────────────
  function showError(msg) {
    parseError.textContent = '✗ ' + msg;
    parseError.classList.remove('hidden');
  }
  function hideError() {
    parseError.classList.add('hidden');
  }
  function esc(str) {
    if (str == null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ── Auto-run default grammar on load ──────────────────────
  window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => performConversion(), 200);
  });

})();
