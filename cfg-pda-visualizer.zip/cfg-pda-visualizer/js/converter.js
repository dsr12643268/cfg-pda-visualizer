// ============================================================
//  CFG → PDA CONVERTER
//  Implements the standard Sipser conversion (acceptance by
//  empty stack, 3-state construction)
// ============================================================

const CFGtoPDA = (() => {

  /**
   * Convert a parsed CFG grammar to a PDA.
   *
   * Returns a PDA object:
   * {
   *   states:     string[]
   *   inputAlpha: string[]   (Σ)
   *   stackAlpha: string[]   (Γ)
   *   start:      string     (q_start)
   *   accept:     string[]   ([q_accept])
   *   transitions: Transition[]
   *   steps:       ConversionStep[]
   * }
   *
   * Transition: { from, input, stackPop, to, stackPush, type, ruleDesc }
   * type: 'init' | 'var' | 'term' | 'accept'
   */
  function convert(grammar) {
    const { variables, terminals, rules, startSymbol } = grammar;

    const Q_START  = 'q_start';
    const Q_LOOP   = 'q_loop';
    const Q_ACCEPT = 'q_accept';
    const BOTTOM   = '$';
    const EPS      = 'ε';

    const states      = [Q_START, Q_LOOP, Q_ACCEPT];
    const stackAlpha  = [...variables, ...terminals, BOTTOM];
    const transitions = [];
    const steps       = [];

    // ── Step 1: Initialization transition ──────────────────────
    // (q_start, ε, ε) → (q_loop, S$)
    transitions.push({
      from:      Q_START,
      input:     EPS,
      stackPop:  EPS,
      to:        Q_LOOP,
      stackPush: startSymbol + BOTTOM,
      type:      'init',
      ruleDesc:  `Initialize stack with ${startSymbol}${BOTTOM}`
    });
    steps.push({
      num:   1,
      title: 'Initialization',
      desc:  `Add transition from q_start to q_loop pushing the start symbol "${startSymbol}" and bottom-of-stack marker "$" onto the stack.`,
      code:  `(q_start, ε, ε) → (q_loop, ${startSymbol}$)`
    });

    // ── Step 2: Variable rules ──────────────────────────────────
    // For each A → w: (q_loop, ε, A) → (q_loop, w)
    steps.push({
      num:   2,
      title: 'Variable Substitution Rules',
      desc:  `For each grammar rule A → w, add a transition that pops A from the stack and pushes w (the right-hand side). This simulates a leftmost derivation.`,
      code:  `For each A → w ∈ R: (q_loop, ε, A) → (q_loop, w)`
    });

    for (const rule of rules) {
      const pushStr = rule.rhs.length === 0
        ? EPS
        : rule.rhs.slice().reverse().join('');   // push in reverse so top of stack is leftmost
      const displayRHS = rule.rhs.length === 0 ? 'ε' : rule.rhs.join('');

      transitions.push({
        from:      Q_LOOP,
        input:     EPS,
        stackPop:  rule.lhs,
        to:        Q_LOOP,
        stackPush: pushStr === EPS ? EPS : rule.rhs.slice().reverse().join(''),
        type:      'var',
        ruleDesc:  `Rule: ${rule.lhs} → ${displayRHS}`,
        displayPush: displayRHS
      });
    }

    // ── Step 3: Terminal matching ───────────────────────────────
    // For each a ∈ Σ: (q_loop, a, a) → (q_loop, ε)
    steps.push({
      num:   3,
      title: 'Terminal Matching',
      desc:  `For each terminal symbol a ∈ Σ, add a transition that reads "a" from input and pops "a" from the stack. This matches terminals in the input string.`,
      code:  `For each a ∈ Σ: (q_loop, a, a) → (q_loop, ε)`
    });

    for (const term of terminals) {
      transitions.push({
        from:      Q_LOOP,
        input:     term,
        stackPop:  term,
        to:        Q_LOOP,
        stackPush: EPS,
        type:      'term',
        ruleDesc:  `Match terminal "${term}"`
      });
    }

    // ── Step 4: Accept transition ───────────────────────────────
    // (q_loop, ε, $) → (q_accept, ε)
    transitions.push({
      from:      Q_LOOP,
      input:     EPS,
      stackPop:  BOTTOM,
      to:        Q_ACCEPT,
      stackPush: EPS,
      type:      'accept',
      ruleDesc:  'Accept: bottom marker reached'
    });
    steps.push({
      num:   4,
      title: 'Accept Condition',
      desc:  `When the bottom-of-stack marker "$" is at the top, the entire input has been matched. Transition to q_accept.`,
      code:  `(q_loop, ε, $) → (q_accept, ε)`
    });

    return {
      states,
      inputAlpha: terminals,
      stackAlpha,
      start:  Q_START,
      accept: [Q_ACCEPT],
      transitions,
      steps,
      grammar
    };
  }

  // ─────────────────────────────────────────────────────────────
  //  String Membership Testing via CYK Algorithm
  // ─────────────────────────────────────────────────────────────

  /**
   * Test if a string is in L(G) using the grammar directly.
   * Uses recursive descent with memoization (handles ε-rules).
   * Returns { accepted: bool, derivation: [{expr, rule}] }
   */
  function testString(grammar, inputStr) {
    if (!grammar) return { accepted: false, derivation: [], error: 'No grammar loaded.' };

    const input = inputStr === 'ε' || inputStr === '' ? [] : inputStr.split('');

    // BFS/iterative derivation for display
    const result = derive(grammar, input);
    return result;
  }

  function derive(grammar, inputChars) {
    const { rules, startSymbol, variables } = grammar;
    const target = inputChars.join('');
    const memo = new Map();

    // We'll do a BFS derivation to find a parse path
    // State: sentential form as array of symbols
    const start = [startSymbol];
    const queue = [{ form: start, history: [{ expr: startSymbol, rule: 'Start' }] }];
    const visited = new Set();
    visited.add(startSymbol);
    const MAX_ITER = 2000;
    let iter = 0;

    while (queue.length > 0 && iter < MAX_ITER) {
      iter++;
      const { form, history } = queue.shift();
      const formStr = form.join('');

      // Check if all terminals
      const allTerminals = form.every(s => !grammar.variables.includes(s));
      if (allTerminals) {
        const result = form.join('');
        if (result === target || (target === '' && result === '')) {
          return { accepted: true, derivation: history };
        }
        continue; // Dead end terminal string
      }

      // Check length — prune if longer than target (only works for non-ε)
      if (target.length > 0) {
        const minLen = form.filter(s => !grammar.variables.includes(s)).length;
        if (minLen > target.length) continue;
      }

      // Find leftmost variable
      const varIdx = form.findIndex(s => grammar.variables.includes(s));
      if (varIdx === -1) continue;
      const variable = form[varIdx];

      // Try all rules for this variable
      for (const rule of rules) {
        if (rule.lhs !== variable) continue;
        const newForm = [
          ...form.slice(0, varIdx),
          ...rule.rhs,
          ...form.slice(varIdx + 1)
        ];
        const newStr = newForm.join('');
        if (visited.has(newStr)) continue;
        visited.add(newStr);

        const ruleDisplay = `${rule.lhs} → ${rule.rhs.length === 0 ? 'ε' : rule.rhs.join('')}`;
        const newHistory = [...history, { expr: newStr || 'ε', rule: ruleDisplay }];
        queue.push({ form: newForm, history: newHistory });
      }
    }

    return { accepted: false, derivation: [] };
  }

  // ─────────────────────────────────────────────────────────────
  //  Presets
  // ─────────────────────────────────────────────────────────────
  const PRESETS = {
    balanced: {
      text: 'S → aSb | ε',
      start: 'S',
      label: 'aⁿbⁿ (n ≥ 0)'
    },
    palindrome: {
      text: 'S → aSa | bSb | a | b | ε',
      start: 'S',
      label: 'Palindromes over {a,b}'
    },
    arithmetic: {
      text: `E → E+T | T
T → T*F | F
F → (E) | a`,
      start: 'E',
      label: 'Arithmetic Expressions'
    },
    nested: {
      text: `S → aSbS | bSaS | ε`,
      start: 'S',
      label: 'Equal a\'s and b\'s'
    }
  };

  return { convert, testString, PRESETS };
})();
